/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_281()
{
    return 3284633928U;
}

unsigned addval_391(unsigned x)
{
    return x + 3279479768U;
}

unsigned addval_416(unsigned x)
{
    return x + 2425362552U;
}

unsigned addval_149(unsigned x)
{
    return x + 3347664115U;
}

void setval_222(unsigned *p)
{
    *p = 3281031256U;
}

void setval_241(unsigned *p)
{
    *p = 2421745830U;
}

unsigned getval_237()
{
    return 3284633928U;
}

void setval_318(unsigned *p)
{
    *p = 3284633944U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_229()
{
    return 3525362315U;
}

unsigned addval_102(unsigned x)
{
    return x + 3224945289U;
}

unsigned getval_330()
{
    return 3221802633U;
}

unsigned getval_445()
{
    return 2430634312U;
}

unsigned getval_261()
{
    return 3769190607U;
}

unsigned addval_480(unsigned x)
{
    return x + 2430634304U;
}

unsigned addval_351(unsigned x)
{
    return x + 3263295750U;
}

unsigned addval_269(unsigned x)
{
    return x + 3232027017U;
}

unsigned getval_254()
{
    return 3281112713U;
}

unsigned getval_264()
{
    return 3286272328U;
}

unsigned addval_496(unsigned x)
{
    return x + 3229929097U;
}

unsigned addval_394(unsigned x)
{
    return x + 3286272332U;
}

void setval_177(unsigned *p)
{
    *p = 3682910921U;
}

unsigned getval_387()
{
    return 1304674969U;
}

unsigned addval_392(unsigned x)
{
    return x + 3222851209U;
}

unsigned getval_163()
{
    return 3223896713U;
}

unsigned getval_398()
{
    return 3381972617U;
}

unsigned addval_255(unsigned x)
{
    return x + 3351415099U;
}

void setval_153(unsigned *p)
{
    *p = 3281047241U;
}

void setval_209(unsigned *p)
{
    *p = 3222851977U;
}

void setval_305(unsigned *p)
{
    *p = 3281047945U;
}

unsigned addval_112(unsigned x)
{
    return x + 3281113481U;
}

void setval_381(unsigned *p)
{
    *p = 3281047945U;
}

unsigned getval_437()
{
    return 3286272320U;
}

unsigned getval_365()
{
    return 3677933185U;
}

unsigned getval_234()
{
    return 3286272072U;
}

unsigned addval_171(unsigned x)
{
    return x + 3527987593U;
}

unsigned getval_231()
{
    return 3229929897U;
}

void setval_267(unsigned *p)
{
    *p = 3224945289U;
}

unsigned addval_384(unsigned x)
{
    return x + 3526938281U;
}

unsigned getval_399()
{
    return 3269495112U;
}

void setval_410(unsigned *p)
{
    *p = 3531919625U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
